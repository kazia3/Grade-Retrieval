#!/usr/bin/env python3

########################################################################

import client_server_template

## or
## from client_server_template import *

########################################################################

client = client_server_template.Client()

## client = Client()


