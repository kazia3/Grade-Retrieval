#!/usr/bin/env python3

########################################################################

import client_server_template

## or
## from client_server_template import *

########################################################################

client = client_server_template.Client()
server = client_server_template.Server()

## or
## client = Client()
## server = Server()




