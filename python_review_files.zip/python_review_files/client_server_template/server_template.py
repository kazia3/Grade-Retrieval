#!/usr/bin/env python3

########################################################################

import client_server_template

## or
## from client_server_template import *

########################################################################

server = client_server_template.Server()

## client = Client()


