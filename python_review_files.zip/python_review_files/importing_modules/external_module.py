#!/usr/bin/env python3

## Print out the value of __name__ in this script.
##
print("Inside external_module.py: __name__ = \"{}\"".format(__name__))

external_name = "Jane Smith"









